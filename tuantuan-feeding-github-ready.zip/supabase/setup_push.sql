-- 在 Supabase SQL Editor 中粘贴并点击 Run 执行
create table if not exists public.push_schedules (
  device_id text primary key,
  family_code text not null,
  author_role text default 'mom',
  subscription jsonb not null,
  next_remind_at timestamptz,
  reminded boolean default false,
  updated_at timestamptz default now()
);

alter table public.push_schedules enable row level security;

create policy "Allow anon all on push_schedules"
  on public.push_schedules for all
  using (true) with check (true);
