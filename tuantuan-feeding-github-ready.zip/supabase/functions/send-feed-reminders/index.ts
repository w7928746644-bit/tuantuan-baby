import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

webpush.setVapidDetails(
  Deno.env.get("VAPID_SUBJECT") || "mailto:admin@example.com",
  Deno.env.get("VAPID_PUBLIC_KEY")!,
  Deno.env.get("VAPID_PRIVATE_KEY")!
);

serve(async () => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const nowIso = new Date().toISOString();
  const { data: dueList } = await supabase
    .from("push_schedules")
    .select("*")
    .eq("reminded", false)
    .not("next_remind_at", "is", null)
    .lte("next_remind_at", nowIso);

  if (!dueList || dueList.length === 0) {
    return new Response(JSON.stringify({ sent: 0 }), { status: 200 });
  }

  let sentCount = 0;
  for (const row of dueList) {
    try {
      await webpush.sendNotification(
        row.subscription,
        JSON.stringify({
          title: "🍼 团团喂奶时间到啦！",
          body: "已到达设定的喂养间隔时间，点击立即记录本次喂奶~",
          tag: `feed-${row.family_code}`
        })
      );
      sentCount++;
    } catch (err: any) {
      if (err.statusCode === 410 || err.statusCode === 404) {
        await supabase.from("push_schedules").delete().eq("device_id", row.device_id);
        continue;
      }
    }

    await supabase
      .from("push_schedules")
      .update({ reminded: true })
      .eq("device_id", row.device_id);
  }

  return new Response(JSON.stringify({ sent: sentCount }), { status: 200 });
});
